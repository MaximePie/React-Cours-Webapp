import React from 'react';

export default function Header() {
    return (
        <div className="Header">
            C'est le component Header
        </div>
    );
}
